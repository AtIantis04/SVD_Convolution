#include <opencv2/opencv.hpp>
#include <Eigen/Dense>
#include <iostream>
#include <chrono>
#include <string>
using namespace std;

template<typename T> static inline T clamp(int x, int low, int high){
    return static_cast<T>(std::max(low, std::min(x, high)));
}

cv::Mat conv1d_horizontal(const cv::Mat& src, const std::vector<float>& h){
    CV_Assert(src.type() == CV_32F);
    int rows = src.rows, cols = src.cols, k = (int)h.size(), r = k/2;
    cv::Mat dst(rows, cols, CV_32F, cv::Scalar(0));
    for(int y=0;y<rows;++y){
        const float* srow=src.ptr<float>(y);
        float* drow=dst.ptr<float>(y);
        for(int x=0;x<cols;++x){
            double acc=0;
            for(int i=-r;i<=r;++i){
                int xx=clamp<int>(x+i,0,cols-1);
                acc += srow[xx]*h[i+r];
            }
            drow[x]=(float)acc;
        }
    }
    return dst;
}

cv::Mat conv1d_vertical(const cv::Mat& src, const std::vector<float>& v){
    CV_Assert(src.type() == CV_32F);
    int rows = src.rows, cols = src.cols, k = (int)v.size(), r = k/2;
    cv::Mat dst(rows, cols, CV_32F, cv::Scalar(0));
    for(int x=0;x<cols;++x){
        for(int y=0;y<rows;++y){
            double acc=0;
            for(int i=-r;i<=r;++i){
                int yy=clamp<int>(y+i,0,rows-1);
                acc += src.ptr<float>(yy)[x]*v[i+r];
            }
            dst.ptr<float>(y)[x]=(float)acc;
        }
    }
    return dst;
}

cv::Mat conv2d_full(const cv::Mat& src, const cv::Mat& K){
    cv::Mat dst; cv::filter2D(src,dst,CV_32F,K,cv::Point(-1,-1),0,cv::BORDER_REPLICATE);
    return dst;
}

void svd_rank1_from_kernel(const cv::Mat& kernel2d,std::vector<float>& V_col,std::vector<float>& H_row){
    CV_Assert(kernel2d.type()==CV_32F);
    int r=kernel2d.rows,c=kernel2d.cols;
    Eigen::MatrixXd K(r,c);
    for(int i=0;i<r;++i){const float* kr=kernel2d.ptr<float>(i);for(int j=0;j<c;++j)K(i,j)=kr[j];}
    Eigen::JacobiSVD<Eigen::MatrixXd> svd(K,Eigen::ComputeThinU|Eigen::ComputeThinV);
    double s0=svd.singularValues()(0);
    Eigen::VectorXd u1=svd.matrixU().col(0),v1=svd.matrixV().col(0);
    double rs=sqrt(max(0.0,s0));
    V_col.resize(r);H_row.resize(c);
    for(int i=0;i<r;++i)V_col[i]=(float)(u1(i)*rs);
    for(int j=0;j<c;++j)H_row[j]=(float)(v1(j)*rs);
}

cv::Mat gaussian2D(int k,double sigma){
    cv::Mat g1=cv::getGaussianKernel(k,sigma,CV_32F);cv::Mat G=g1*g1.t();G/=cv::sum(G)[0];return G;
}

int main(int argc,char**argv){
    string imgPath=(argc>1)?argv[1]:"",mode=(argc>2)?argv[2]:"gauss";
    cv::Mat img;
    if(!imgPath.empty()){img=cv::imread(imgPath,cv::IMREAD_GRAYSCALE);if(img.empty()){cerr<<"No se pudo leer "<<imgPath<<endl;return 1;}}
    else {img=cv::Mat(256,256,CV_8U);cv::randu(img,0,255);}
    img.convertTo(img,CV_32F,1.0/255.0);
    cv::Mat K2D=gaussian2D(15,2.5);
    auto t0=chrono::high_resolution_clock::now();
    cv::Mat ref=conv2d_full(img,K2D);
    auto t1=chrono::high_resolution_clock::now();
    vector<float>Vc,Hr;svd_rank1_from_kernel(K2D,Vc,Hr);
    auto t2=chrono::high_resolution_clock::now();
    cv::Mat tmp=conv1d_horizontal(img,Hr),sep=conv1d_vertical(tmp,Vc);
    auto t3=chrono::high_resolution_clock::now();
    double mse=0,maxAbs=0;cv::Mat diff;cv::absdiff(ref,sep,diff);
    maxAbs=cv::norm(diff,cv::NORM_INF);mse=cv::norm(diff,cv::NORM_L2SQR)/(img.rows*img.cols);
    cout<<"Tiempo 2D(ms):"<<chrono::duration<double,milli>(t1-t0).count()
        <<" Separable(ms):"<<chrono::duration<double,milli>(t3-t2).count()
        <<" MSE:"<<mse<<" MaxDiff:"<<maxAbs<<endl;
    cv::imwrite("out_ref2d.png",ref*255);cv::imwrite("out_sep.png",sep*255);
    cv::imwrite("out_absdiff.png",diff*255);
    return 0;
}
